const Email = require('email-templates');

const email = new Email({
  message: {
    from: 'anupama@eazyerp.comm'
  },
  // uncomment below to send emails in development/test env:
  // send: true
  transport: {
    jsonTransport: true
  }
});

email
  .send({
    template: 'mars',
    message: {
      to: 'maduriyaanupama@gmail.com'
    },
    locals: {
      name: 'Elon'
    }
  })
  .then(console.log)
  .catch(console.error);