console.log('hello');
const userId=1001
let userName="anupama";
userCity="Delhi";
let testFile;

console.table([userName ,  userId ,userCity,testFile]);


